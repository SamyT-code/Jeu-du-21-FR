﻿'**********************************
'*Travail : Jeu du 21
'*Programmeur : Samy Touabi
'*Date de conception : 3 mai 2020
'*********************************
Public Class frmMenu
    Private Sub JouerAuJeuDu21ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MenuItemJouer.Click

        FrmJeu21.Show() 'Afficher la fenêtre qui contient le jeu

    End Sub

End Class
